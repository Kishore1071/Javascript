import React from 'react'
import { useState } from 'react'

function SecondComponent() {

  const [name, setName] = useState('Steven Rogers')

  function ConsoleData () {
    console.log("New Data")
  }


  return (
    <div>
        {console.log(name)}
        <h1>{name}</h1>

        <button onClick={() => setName("Captain America")}>Change Name</button>

        <form action="">
          <input type="text" name="" id="" onChange={(event) => setName(event.target.value)} />
        </form> 

        <button onClick={ConsoleData}>Click</button>
    </div>
  )
}

export default SecondComponent