import React from 'react'

const PersonDetails = (props) => {

  const {person_name, designation} = props

  return (
    <div>
        {person_name}
        <br />
        {designation}
    </div>
  )
}

export default PersonDetails