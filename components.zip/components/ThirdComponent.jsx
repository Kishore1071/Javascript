import React, { Component } from 'react'

class ThirdComponent extends Component {

  constructor() {
    super()

    this.state = {
      name: "Antony Stark",
      count: 0
    }
  }

  ChangeName() {
    console.log(this.state.name)
    this.setState(
      {
        name: "IronMan"
      }
    )
  }

  Increment = () => {
    this.setState(
      {
        count: this.state.count + 2
      },
      () => console.log(this.state.count)
    )
  }

  // Increment = () => {
  //   this.setState((previousState) => ({
  //     count: previousState.count + 2
  //   }))
  // }

  // IncrementTen () {
  //   this.Increment()
  //   this.Increment()
  //   this.Increment()
  //   this.Increment()
  //   this.Increment()
  //   this.Increment()
  //   this.Increment()
  //   this.Increment()
  //   this.Increment()
  //   this.Increment()
  // }

  render() {
    
    return (
      <div>
        <h1 className=''>My name is {this.state.name}</h1>
        <button onClick={() => this.ChangeName()}>Change name</button>

        <p>Count {this.state.count}</p>
        <button onClick={() => this.Increment()}>Increment</button>
        {/* <button onClick={() => this.IncrementTen()}>Increment</button> */}
      </div>
    )
  }
}

export default ThirdComponent