import React from 'react'
import SecondComponent from './SecondComponent'
import PersonDetails from './PersonDetails'

function FristComponent() {
  return (
    <div>
        <h1>FristComponent</h1>
        <SecondComponent></SecondComponent>
        <PersonDetails person_name="Aravind" designation="Student"></PersonDetails>
    </div>
  )
}

export default FristComponent